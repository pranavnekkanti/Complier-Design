#include<stdio.h>
#include<conio.h>
void main()
{
    int a,b,c;
    a=1;
    b=2;
    c=a+b;
    printf("Sum:%d",c);
}